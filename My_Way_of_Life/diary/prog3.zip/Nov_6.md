

Program 3 (ferns) involves too many equations and custom data structures to draw the fern the way I wanted to, so I haven't finished it yet and thus haven't turned anything in. If you would like me to turn in a minimum effort program, just tell me, but I plan on finishing program 3 soon. I'm hoping that after I take my nap later I can finish the program.

The next paragraph is only here because I want to share how I feel / felt. Hopefully, you don't have an issue with that. Hopefully, as a human, you understand.

When I was working on program 3, I had fun for a while, but I kept having trouble debugging it because of errors I made, and because of all of the equations that I did not understand. In fact, I still don't understand the equations. Not understanding the equations is really bugging me. Maybe it is the case that {I do understand the equations but I don't understand the way the equations affect the values observed in the objects}. I'm not sure which is the case. Anyways, not understanding whatever it is that I don't understand causes an intense feeling or fear and worry within me. Well, actually, it's the act of me not doing anything to gain an understanding of it that causes fear. I really don't like not understanding things, and for some reason it triggers my fight or flight response. It's even worse at times like right now when I haven't gotten enough sleep.

Yeah, I really, really don't want to turn in any kind of a program for program 3 right now. I will just get extremely irritated extremely fast.

I'm going to need a lot of sleep, and a lot of time to gain an understand of whatever it is that I don't understand.

If you want, I can post a link to a desmos graph if I end up getting something together. It will not look like a fern, but it might, maybe, show an interesting program. There is a good chance it might be a long time before I understand whatever it is that I don't understand enough for me to be able to make a desmos graph. Actually, now that I'm thinking about it more, I will post some links of a few desmos graphs of me trying to understand whatever it is that I don't understand. Yeah. That way you might be able to partially understand why I am having a hard time, but it might require you to waste a lot of your own time thinking about it yourself.

If you read all of this, I'm really grateful for your time, and I hope you have a good day. Program 3 has really been bothering me, and I won't just leave it in the trash bin. But understanding equations and visuals is just really difficult for me sometimes. I have this same problem in my dreams. It is always some strange object that has some strange interaction with another object. Ahh, why is it so hard to understand though? My subconcious is still bugged by this. It's been getting bugged by it for 20 years now. What is it that you're trying to understand? Hmm... I need to get to the bottom of this.

Ugh. I'm really sorry for being so late on the assignment. I'm an imperfect human being, and I have a lot of personal issues that I need to tend to, as well as some maturing to do. And there is some strange puzzle that's bugged me all my life and I've never been able to put it to words. Well, I guess that is my main personal issue. Regardless, it really plagues me, and I'm really excited about trying to make some progress towards figuring out what in the world it is.

